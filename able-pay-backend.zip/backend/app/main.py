import os
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field
from pwdlib import PasswordHash
from sqlalchemy import DateTime, ForeignKey, Numeric, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ablepay.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
JWT_SECRET = os.getenv("JWT_SECRET", "CHANGE_THIS_DEVELOPMENT_SECRET_BEFORE_DEPLOYING")
JWT_ALGORITHM = "HS256"
TOKEN_MINUTES = int(os.getenv("TOKEN_MINUTES", "720"))
password_hash = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)

app = FastAPI(title="ABLE PAY API", version="0.1.0", description="Development API for ABLE PAY Nigeria")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Idempotency-Key"],
)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    full_name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    phone: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Wallet(Base):
    __tablename__ = "wallets"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), unique=True, index=True)
    currency: Mapped[str] = mapped_column(String(3), default="NGN")
    balance: Mapped[Decimal] = mapped_column(Numeric(18, 2), default=Decimal("0.00"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    wallet_id: Mapped[str] = mapped_column(ForeignKey("wallets.id"), index=True)
    direction: Mapped[str] = mapped_column(String(8))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    description: Mapped[str] = mapped_column(String(180))
    reference: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class RegisterBody(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    phone: str = Field(min_length=7, max_length=32)
    password: str = Field(min_length=8, max_length=128)

class LoginBody(BaseModel):
    email: EmailStr
    password: str

class TransferBody(BaseModel):
    recipient_email: EmailStr
    amount: Decimal = Field(gt=0, max_digits=16, decimal_places=2)
    note: str = Field(default="ABLE PAY transfer", max_length=180)


def create_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": user.id, "iat": now, "exp": now + timedelta(minutes=TOKEN_MINUTES)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Please log in")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Session expired. Please log in again.")
    user = db.get(User, user_id) if user_id else None
    if not user:
        raise HTTPException(status_code=401, detail="Account not found")
    return user


def money(value: Decimal) -> str:
    return f"{Decimal(value):.2f}"

@app.get("/")
def root():
    return {"service": "ABLE PAY API", "status": "online", "mode": "development"}

@app.get("/health")
def health():
    return {"ok": True, "service": "able-pay-api"}

@app.post("/auth/register", status_code=201)
def register(body: RegisterBody, db: Session = Depends(get_db)):
    email = body.email.lower()
    phone = body.phone.strip()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    if db.scalar(select(User).where(User.phone == phone)):
        raise HTTPException(status_code=409, detail="An account with this phone number already exists")
    user = User(full_name=body.full_name.strip(), email=email, phone=phone, password_hash=password_hash.hash(body.password))
    db.add(user)
    db.flush()
    wallet = Wallet(user_id=user.id, balance=Decimal("0.00"), currency="NGN")
    db.add(wallet)
    db.commit()
    return {"access_token": create_token(user), "token_type": "bearer", "user": {"id": user.id, "full_name": user.full_name, "email": user.email, "phone": user.phone}}

@app.post("/auth/login")
def login(body: LoginBody, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not password_hash.verify(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"access_token": create_token(user), "token_type": "bearer", "user": {"id": user.id, "full_name": user.full_name, "email": user.email, "phone": user.phone}}

@app.get("/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "full_name": user.full_name, "email": user.email, "phone": user.phone}

@app.get("/wallet")
def wallet(user: User = Depends(current_user), db: Session = Depends(get_db)):
    item = db.scalar(select(Wallet).where(Wallet.user_id == user.id))
    if not item:
        raise HTTPException(status_code=404, detail="Wallet not found")
    return {"currency": item.currency, "balance": money(item.balance), "wallet_id": item.id}

@app.get("/wallet/transactions")
def transactions(user: User = Depends(current_user), db: Session = Depends(get_db)):
    item = db.scalar(select(Wallet).where(Wallet.user_id == user.id))
    if not item:
        raise HTTPException(status_code=404, detail="Wallet not found")
    entries = db.scalars(select(LedgerEntry).where(LedgerEntry.wallet_id == item.id).order_by(LedgerEntry.created_at.desc()).limit(50)).all()
    return [{"id": x.id, "direction": x.direction, "amount": money(x.amount), "description": x.description, "reference": x.reference, "created_at": x.created_at.isoformat()} for x in entries]

@app.post("/transfers/internal")
def internal_transfer(body: TransferBody, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if body.amount <= 0 or body.amount.quantize(Decimal("0.01")) != body.amount:
        raise HTTPException(status_code=422, detail="Enter an amount with up to 2 decimal places")
    recipient = db.scalar(select(User).where(User.email == body.recipient_email.lower()))
    if not recipient:
        raise HTTPException(status_code=404, detail="ABLE PAY recipient not found")
    if recipient.id == user.id:
        raise HTTPException(status_code=400, detail="You cannot transfer to yourself")
    sender_wallet = db.scalar(select(Wallet).where(Wallet.user_id == user.id).with_for_update())
    recipient_wallet = db.scalar(select(Wallet).where(Wallet.user_id == recipient.id).with_for_update())
    if not sender_wallet or not recipient_wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    if sender_wallet.balance < body.amount:
        raise HTTPException(status_code=400, detail="Insufficient wallet balance")
    reference = "AP-" + uuid.uuid4().hex[:20].upper()
    sender_wallet.balance = Decimal(sender_wallet.balance) - body.amount
    recipient_wallet.balance = Decimal(recipient_wallet.balance) + body.amount
    db.add_all([
        LedgerEntry(wallet_id=sender_wallet.id, direction="debit", amount=body.amount, description=body.note, reference=reference + "-D"),
        LedgerEntry(wallet_id=recipient_wallet.id, direction="credit", amount=body.amount, description=f"Received from {user.full_name}", reference=reference + "-C"),
    ])
    db.commit()
    return {"status": "successful", "reference": reference, "amount": money(body.amount), "currency": "NGN", "recipient": recipient.email, "message": "Internal ABLE PAY transfer completed"}

@app.post("/payments/provider-not-configured")
def provider_not_configured():
    raise HTTPException(status_code=503, detail="A licensed payment provider has not been connected. No money was moved.")
